"use client"

import { useCallback, useEffect, useRef, useState } from "react"
import type { Ticket } from "@/lib/dispatch"
import { IntakeFeed, type FeedState } from "@/components/intake-feed"
import { MapView } from "@/components/map-view"

export default function Page() {
  const [tickets, setTickets] = useState<Ticket[]>([])
  const [activeId, setActiveId] = useState<string | null>(null)
  const [feedState, setFeedState] = useState<FeedState>("loading")
  const [refreshVersion, setRefreshVersion] = useState(0)
  const sessionStartedAt = useRef<number | null>(null)
  const previousData = useRef("")
  const knownIds = useRef(new Set<string>())
  const refresh = useCallback(() => setRefreshVersion((value) => value + 1), [])

  useEffect(() => {
    // A new page load starts an empty session. Keep this boundary through
    // polling, manual feed refreshes and React's development effect replay.
    // Use the call's end time so delayed analysis cannot revive old reports.
    sessionStartedAt.current ??= Date.now()
    const startedAt = sessionStartedAt.current
    let stopped = false
    let timer: ReturnType<typeof setTimeout>
    const controller = new AbortController()
    async function poll() {
      try {
        const response = await fetch("/api/reports", {
          cache: "no-store",
          signal: AbortSignal.any([controller.signal, AbortSignal.timeout(10_000)]),
        })
        if (!response.ok) throw new Error("Report feed unavailable")
        const data = await response.json() as { tickets: Ticket[] }
        if (!Array.isArray(data.tickets)) throw new Error("Invalid report feed")
        if (stopped) return
        const currentTickets = data.tickets.filter((ticket) =>
          Number.isFinite(ticket.createdAt) && ticket.createdAt >= startedAt
        )
        const serialized = JSON.stringify(currentTickets)
        if (serialized !== previousData.current) {
          const newest = currentTickets.find((ticket) => !knownIds.current.has(ticket.id))
          knownIds.current = new Set(currentTickets.map((ticket) => ticket.id))
          previousData.current = serialized
          setTickets(currentTickets)
          setActiveId((current) => newest?.id ?? (currentTickets.some((ticket) => ticket.id === current) ? current : currentTickets[0]?.id ?? null))
        }
        setFeedState("connected")
      } catch {
        if (!stopped) setFeedState("error")
      } finally {
        if (!stopped) timer = setTimeout(poll, 2000)
      }
    }
    void poll()
    return () => { stopped = true; controller.abort(); clearTimeout(timer) }
  }, [refreshVersion])

  return (
    <main className="flex h-dvh min-h-[600px] w-full flex-col overflow-hidden bg-gray-900 text-white md:flex-row">
      <div className="h-[58%] min-h-0 w-full md:h-full md:w-[34%] md:min-w-[340px] md:max-w-[440px]">
        <IntakeFeed tickets={tickets} activeId={activeId} feedState={feedState} onSelect={setActiveId} onRefresh={refresh} />
      </div>
      <div className="min-h-0 flex-1">
        <MapView tickets={tickets} activeId={activeId} />
      </div>
    </main>
  )
}
