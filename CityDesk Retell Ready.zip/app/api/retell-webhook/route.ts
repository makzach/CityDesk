import { asRecord, reportFromCall } from "@/lib/retell-report"
import { verifyRetellSignature } from "@/lib/retell-signature"
import { saveReport, storageConfigured } from "@/lib/report-store"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

export async function POST(request: Request): Promise<Response> {
  const key = process.env.RETELL_API_KEY
  const agentId = process.env.NEXT_PUBLIC_RETELL_AGENT_ID
  if (!key || !agentId || !storageConfigured()) {
    return Response.json({ error: "Report integration is not configured" }, { status: 503 })
  }
  if (Number(request.headers.get("content-length")) > 1_048_576) {
    return Response.json({ error: "Payload too large" }, { status: 413 })
  }
  const rawBody = await request.text()
  if (Buffer.byteLength(rawBody) > 1_048_576) {
    return Response.json({ error: "Payload too large" }, { status: 413 })
  }
  if (!verifyRetellSignature(rawBody, request.headers.get("x-retell-signature"), key)) {
    return Response.json({ error: "Invalid signature" }, { status: 401 })
  }

  let payload: Record<string, unknown> | null
  try { payload = asRecord(JSON.parse(rawBody)) }
  catch { return Response.json({ error: "Invalid JSON" }, { status: 400 }) }
  if (!payload) return Response.json({ error: "Invalid payload" }, { status: 400 })
  if (payload.event !== "call_analyzed") return new Response(null, { status: 204 })
  const call = asRecord(payload.call)
  if (!call) return Response.json({ error: "Missing call" }, { status: 400 })
  if (call.agent_id !== agentId) return new Response(null, { status: 204 })
  const report = reportFromCall(call)
  if (!report) return new Response(null, { status: 204 })

  try {
    await saveReport(report)
    return new Response(null, { status: 204 })
  } catch {
    // A non-2xx response lets Retell retry. Never log caller data or credentials.
    console.error("CityDesk: could not persist the Retell report")
    return Response.json({ error: "Report could not be saved; retry delivery" }, { status: 503 })
  }
}
