import { listReports, storageConfigured } from "@/lib/report-store"
import { historyConfigured, listRetellReports } from "@/lib/retell-history"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

// Public hackathon dashboard for fictional incident reports.
// No raw audio, transcripts, caller phone numbers or Retell tokens are returned.
export async function GET(): Promise<Response> {
  const headers = { "Cache-Control": "no-store, max-age=0" }
  if (!storageConfigured() && !historyConfigured()) {
    return Response.json({ error: "Report connection is not configured" }, { status: 503, headers })
  }
  try {
    const tickets = storageConfigured() ? await listReports() : await listRetellReports()
    return Response.json({ tickets }, { headers })
  } catch {
    return Response.json({ error: "Reports are temporarily unavailable" }, { status: 503, headers })
  }
}
