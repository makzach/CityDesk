# St. George / Robarts water-leak update

## Update your existing website on your Mac

1. Download `citydesk-robarts-update.zip` into Downloads. Leave it zipped.
2. In the Terminal that is running your website, press Control + C.
3. Run:

```sh
unzip -o ~/Downloads/citydesk-robarts-update.zip -d ~/Downloads/citydesk-retell-ready
cd ~/Downloads/citydesk-retell-ready
npm run dev
```

4. Refresh the address shown in Terminal, usually `http://localhost:3000`.

The update contains only source files and instructions. It leaves your `.env.local`, keys and installed packages in place. No new packages, paid services or keys are needed for this change. Voice calls still use your existing Retell balance.

## Update the voice in Retell

The website files cannot change the prompt stored in your Retell account.

The prompt also includes the natural-closing and **Saint George Street** pronunciation fix. See `VOICE_TUNING.md` for the closing sequence and the optional End Call tool setting.

1. Open your existing CityDesk voice agent in Retell. Replace its single prompt with all the text in `RETELL_AGENT_PROMPT.txt` from this folder.
2. If the agent has a separately configured welcome/begin message, replace that too:

   > Thanks for contacting CityDesk. What would you like to report?

3. In Post Call Extraction, keep the six field names below. Add **Water Leak** to the `issue_category` selector if it is not already there. If it is a text field, include Water Leak in its extraction instructions.
4. Save the changes and publish the updated version used by your website's voice agent, then start a new conversation.

| Field | Extraction instruction |
| --- | --- |
| `issue_category` | Extract the final reported issue. Use Water Leak for a water leak; other allowed values: Pothole, Road Damage, Other. |
| `description` | Summarize only the final reported issue and details. Do not include invented severity or rejected earlier facts. |
| `street_or_intersection` | Extract only the final corrected street or intersection. For this location use St. George Street. |
| `city` | Extract the city, defaulting to Toronto if no other city was stated. |
| `location_details` | Extract the final landmark and positioning details. If reported, use Across from Robarts Library. Add further positioning after a semicolon. |
| `caller_confirmed` | Boolean: true only when the caller explicitly confirms the final read-back; otherwise false. |

Retell's single prompt controls the spoken behavior; extraction settings control the saved fields. [Single-prompt documentation](https://docs.retellai.com/build/single-multi-prompt/prompt-overview) · [Post-call extraction documentation](https://docs.retellai.com/features/post-call-analysis-overview).

## Rehearse the call

With the fresh-session update installed, refresh the browser to start with an empty feed and the map zoomed out. **City view** also zooms out while keeping the current session's reports. Then open **Talk to CityDesk** and say:

> There is a water leak on St. George Street, across from Robarts Library in Toronto.

Answer the follow-up using your planned scenario, confirm the summary, and end the call. After Retell finishes processing, the website creates a report card, labels it Water Leak, places its pin at the St. George Street reference point opposite Robarts, and zooms in. It does not pin mid-sentence: this integration uses post-call analysis.

The point is approximately **43.664705, -79.398653**, on St. George Street between Harbord and Sussex, opposite [Robarts Library](https://library.utoronto.ca/library/robarts). It is a preset reference point for that reported area, not a measurement of the exact leak. The matcher accepts St. / Saint / Saint Georges, and it also works when Retell separates the street from the landmark. A vague street alone or an unconfirmed report does not get a guessed pin.

The website no longer displays demo wording. Reports show **Awaiting review**. The system creates CityDesk reports; it does not create official city service requests or dispatch crews.
