"use client"

import { useCallback, useEffect, useRef } from "react"
import Map, { Marker, NavigationControl, type MapRef } from "react-map-gl/maplibre"
import type { StyleSpecification } from "maplibre-gl"
import { MapPin, Radar } from "lucide-react"
import "maplibre-gl/dist/maplibre-gl.css"

import { TORONTO_CENTER, hasMapLocation, type Ticket } from "@/lib/dispatch"

// Token-free dark basemap using Esri's free "Dark Gray Canvas" raster tiles
// (base + reference labels). No API key required.
const DARK_STYLE: StyleSpecification = {
  version: 8,
  sources: {
    "esri-dark": {
      type: "raster",
      tiles: [
        "https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}",
      ],
      tileSize: 256,
      // Toronto tiles above level 16 return "Map data not yet available".
      // Overscale the available tiles for a reliable street-level close-up.
      maxzoom: 16,
      attribution: "Esri, HERE, Garmin, © OpenStreetMap contributors",
    },
    "esri-dark-labels": {
      type: "raster",
      tiles: [
        "https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Reference/MapServer/tile/{z}/{y}/{x}",
      ],
      tileSize: 256,
      maxzoom: 16,
    },
  },
  layers: [
    { id: "background", type: "background", paint: { "background-color": "#0b0f14" } },
    { id: "esri-dark", type: "raster", source: "esri-dark" },
    { id: "esri-dark-labels", type: "raster", source: "esri-dark-labels" },
  ],
}

export function MapView({ tickets, activeId }: { tickets: Ticket[]; activeId: string | null }) {
  const mapRef = useRef<MapRef | null>(null)
  const selected = tickets.find((ticket) => ticket.id === activeId)
  const location = selected && hasMapLocation(selected) ? selected : null
  const longitude = location?.lng
  const latitude = location?.lat

  // Focus both when a report arrives and when the map finishes loading.
  // Unchanged polling results must not keep moving the camera.
  const focusOnReport = useCallback(() => {
    if (!activeId || longitude === undefined || latitude === undefined) return
    mapRef.current?.flyTo({
      center: [longitude, latitude],
      zoom: 17.4,
      duration: 1400,
      essential: true,
    })
  }, [activeId, longitude, latitude])
  useEffect(focusOnReport, [focusOnReport])

  // Only confirmed reports with a supported location have a pin.
  const pinned = tickets.filter(hasMapLocation)

  return (
    <div className="relative h-full w-full">
      <Map
        ref={mapRef}
        mapStyle={DARK_STYLE}
        initialViewState={TORONTO_CENTER}
        maxZoom={19}
        onLoad={focusOnReport}
        attributionControl={{ compact: true }}
        style={{ width: "100%", height: "100%" }}
      >
        <NavigationControl position="bottom-left" showCompass={false} />

        {pinned.map((ticket) => {
          const isActive = ticket.id === activeId
          const color = "text-cyan-400"
          return (
            <Marker key={ticket.id} longitude={ticket.lng} latitude={ticket.lat} anchor="bottom" style={{ zIndex: isActive ? 10 : 1 }}>
              <div className="relative flex flex-col items-center" role="img" aria-label={`${ticket.issueType}: ${ticket.address}`}>
                {isActive && (
                  <div className="pointer-events-none absolute bottom-full mb-3 w-max max-w-[230px] rounded-lg border border-cyan-400/40 bg-gray-950/95 px-3 py-2 text-center shadow-xl">
                    <div className="text-xs font-semibold text-cyan-200">{ticket.issueType}</div>
                    <div className="mt-0.5 text-[10px] text-gray-300">{ticket.address}</div>
                  </div>
                )}
                {isActive && (
                  <span
                    className={`absolute -bottom-1 h-4 w-4 rounded-full bg-cyan-500/40 ${
                      isActive ? "animate-ping" : ""
                    }`}
                  />
                )}
                <MapPin
                  className={`relative h-8 w-8 drop-shadow-[0_2px_6px_rgba(0,0,0,0.8)] ${color} ${
                    isActive ? "scale-125" : ""
                  } transition-transform`}
                  strokeWidth={2.25}
                  fill="currentColor"
                  fillOpacity={0.25}
                />
              </div>
            </Marker>
          )
        })}
      </Map>

      {/* HUD overlay */}
      <div className="pointer-events-none absolute left-4 top-4 flex items-center gap-2 rounded-lg border border-white/10 bg-gray-900/80 px-3 py-2 backdrop-blur">
        <Radar className="h-4 w-4 animate-pulse text-cyan-400" />
        <span className="text-xs font-medium tracking-wide text-gray-300">
          TORONTO · REPORT MAP
        </span>
      </div>

      <button
        type="button"
        className="absolute left-4 top-16 rounded-lg border border-white/10 bg-gray-900/90 px-3 py-2 text-xs text-gray-300 backdrop-blur transition-colors hover:border-cyan-400/40 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400"
        onClick={() => mapRef.current?.flyTo({
          center: [TORONTO_CENTER.longitude, TORONTO_CENTER.latitude],
          zoom: TORONTO_CENTER.zoom,
          duration: 1000,
        })}
      >
        City view
      </button>

      <div className="pointer-events-none absolute right-4 top-4 rounded-lg border border-white/10 bg-gray-900/80 px-3 py-2 text-right backdrop-blur">
        <div className="text-2xl font-semibold tabular-nums text-white">{pinned.length}</div>
        <div className="text-[10px] uppercase tracking-widest text-gray-400">Report Pins</div>
      </div>
    </div>
  )
}
