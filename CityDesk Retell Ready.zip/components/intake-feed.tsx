"use client"

import { Inbox, Loader2, RefreshCw } from "lucide-react"
import type { Ticket } from "@/lib/dispatch"
import { VoiceIntake } from "@/components/voice-intake"
import { TicketCard } from "@/components/ticket-card"

export type FeedState = "loading" | "connected" | "error"

export function IntakeFeed({ tickets, activeId, feedState, onSelect, onRefresh }: {
  tickets: Ticket[]
  activeId: string | null
  feedState: FeedState
  onSelect: (id: string) => void
  onRefresh: () => void
}) {
  return (
    <aside className="flex h-full w-full flex-col border-r border-white/10 bg-gray-900">
      <VoiceIntake />
      <div className="flex shrink-0 items-center justify-between px-4 py-3">
        <h2 className="text-xs font-semibold uppercase tracking-widest text-gray-400">Intake Feed</h2>
        <div className="flex items-center gap-2">
          <span className="rounded-full bg-cyan-500/15 px-2 py-0.5 text-[11px] font-semibold text-cyan-300">{tickets.length} reports</span>
          <button type="button" onClick={onRefresh} aria-label="Refresh reports" className="rounded p-1 text-gray-400 hover:bg-gray-800 hover:text-white">
            <RefreshCw className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
      <div role="status" aria-live="polite" className="px-4 pb-3 text-[11px]">
        {feedState === "loading" && <span className="flex items-center gap-2 text-gray-400"><Loader2 className="h-3 w-3 animate-spin" /> Connecting to reports…</span>}
        {feedState === "connected" && <span className="flex items-center gap-2 text-emerald-300"><span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> Reports connected · updates automatically</span>}
        {feedState === "error" && <span className="text-amber-300">Report connection unavailable. Retrying automatically; existing reports remain visible.</span>}
      </div>
      <div className="min-h-0 flex-1 space-y-3 overflow-y-auto px-4 pb-4">
        {tickets.length === 0 ? (
          <div className="flex flex-col items-center justify-center gap-3 rounded-xl border border-dashed border-white/10 px-4 py-10 text-center">
            <Inbox className="h-8 w-8 text-gray-600" />
            <p className="max-w-[15rem] text-xs leading-relaxed text-gray-400">No reports this session. Finish a conversation with CityDesk and its report will appear after analysis.</p>
          </div>
        ) : tickets.map((ticket) => <TicketCard key={ticket.id} ticket={ticket} isActive={ticket.id === activeId} onSelect={onSelect} />)}
      </div>
    </aside>
  )
}
