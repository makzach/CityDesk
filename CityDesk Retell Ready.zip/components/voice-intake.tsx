"use client"

import Script from "next/script"
import { useState } from "react"
import { Mic, Loader2, CircleAlert } from "lucide-react"

export function VoiceIntake() {
  const agentId = process.env.NEXT_PUBLIC_RETELL_AGENT_ID
  const publicKey = process.env.NEXT_PUBLIC_RETELL_PUBLIC_KEY
  const configured = Boolean(agentId && publicKey)
  const [loaded, setLoaded] = useState(false)
  const [failed, setFailed] = useState(false)

  return (
    <div className="shrink-0 border-b border-white/10 bg-gray-900/60 p-4">
      <div className="mb-4 flex items-center justify-between gap-3">
        <div>
          <h1 className="text-sm font-semibold tracking-wide text-white">CityDeskOS</h1>
          <p className="text-[10px] uppercase tracking-widest text-cyan-400/80">
            Non-emergency reporting
          </p>
        </div>
        <div className="flex h-11 w-11 items-center justify-center rounded-full border border-cyan-400/30 bg-cyan-400/10 text-cyan-300">
          <Mic className="h-5 w-5" />
        </div>
      </div>
      <div className="rounded-xl border border-cyan-400/20 bg-cyan-400/5 p-3">
        <h2 className="text-sm font-semibold text-cyan-100">Report an issue by voice</h2>
        <p className="mt-1.5 text-xs leading-relaxed text-gray-300">
          Open <strong>Talk to CityDesk</strong> at the bottom right and allow your microphone.
          Tell the assistant what happened and confirm the location.
        </p>
        <p className="mt-2 text-xs leading-relaxed text-gray-400">
          End the conversation when you are done. Your report appears here after the call is analyzed.
        </p>
        <div className="mt-3 flex items-center gap-2 text-[11px]" role="status">
          {!configured ? (
            <><CircleAlert className="h-3.5 w-3.5 text-amber-400" /><span className="text-amber-300">Voice chat is not connected yet.</span></>
          ) : failed ? (
            <><CircleAlert className="h-3.5 w-3.5 text-amber-400" /><span className="text-amber-300">Voice chat could not load. Refresh to retry.</span></>
          ) : !loaded ? (
            <><Loader2 className="h-3.5 w-3.5 animate-spin text-cyan-300" /><span className="text-gray-400">Loading voice chat…</span></>
          ) : (
            <><span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /><span className="text-emerald-300">Voice widget loaded</span></>
          )}
        </div>
      </div>
      <details className="mt-3 text-[11px] text-gray-400">
        <summary className="cursor-pointer hover:text-gray-200">Map coverage</summary>
        <p className="mt-2 leading-relaxed">St. George Street across from Robarts Library · College &amp; Spadina · College &amp; Bathurst · Bata Shoe Museum. Other locations are saved for review.</p>
      </details>
      {configured && (
        <Script
          id="retell-widget"
          src="https://dashboard.retellai.com/retell-widget-v2.js"
          type="module"
          strategy="afterInteractive"
          data-voice-public-key={publicKey}
          data-voice-agent-id={agentId}
          data-title="CityDesk"
          data-fab-text="Talk to CityDesk"
          data-bot-name="CityDesk"
          data-color="#0891b2"
          data-show-ai-popup="false"
          onReady={() => setLoaded(true)}
          onError={() => setFailed(true)}
        />
      )}
    </div>
  )
}
