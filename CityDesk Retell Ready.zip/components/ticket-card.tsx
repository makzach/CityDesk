"use client"

import { Check, MapPin, Clock, CircleAlert } from "lucide-react"
import { hasMapLocation, type Ticket } from "@/lib/dispatch"

export function TicketCard({ ticket, isActive, onSelect }: {
  ticket: Ticket
  isActive: boolean
  onSelect: (id: string) => void
}) {
  const mapped = hasMapLocation(ticket)
  return (
    <button
      type="button"
      onClick={() => onSelect(ticket.id)}
      aria-pressed={isActive}
      className={`w-full rounded-xl border p-4 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 ${
        isActive ? "border-cyan-400/60 bg-gray-800/80 ring-1 ring-cyan-400/30"
          : "border-white/10 bg-gray-800/40 hover:border-white/20 hover:bg-gray-800/60"
      }`}
    >
      <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
        <span className="text-sm font-semibold text-white">{ticket.issueType}</span>
        <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-semibold ${
          ticket.status === "ready" ? "bg-emerald-500/15 text-emerald-300" : "bg-amber-500/15 text-amber-300"
        }`}>
          {ticket.status === "ready" ? <Check className="h-3 w-3" /> : <CircleAlert className="h-3 w-3" />}
          {ticket.status === "ready" ? "New report" : "Needs review"}
        </span>
      </div>
      <div className="mb-2 flex items-start gap-2 text-sm text-gray-200">
        <MapPin className={`mt-0.5 h-4 w-4 shrink-0 ${mapped ? "text-cyan-400" : "text-amber-400"}`} />
        <span>{ticket.address || "Location not provided"}<span className="block text-[11px] text-gray-500">{ticket.city}</span></span>
      </div>
      <p className="whitespace-pre-wrap break-words rounded-md bg-gray-950/50 p-2 text-xs leading-relaxed text-gray-300">
        {ticket.description || "No description provided."}
      </p>
      {ticket.locationDetails && <p className="mt-2 text-xs text-gray-400">{ticket.locationDetails}</p>}
      <div className="mt-3 flex flex-wrap items-center gap-2 text-[10px]">
        <span className={`rounded border px-1.5 py-0.5 ${ticket.callerConfirmed === true
          ? "border-emerald-400/20 text-emerald-300" : "border-amber-400/20 text-amber-300"}`}>
          {ticket.callerConfirmed === true ? "Caller confirmed" : "Not confirmed"}
        </span>
        <span className="text-gray-500">{mapped ? "Location mapped" : "No map pin"}</span>
      </div>
      {ticket.reviewReasons.length > 0 && (
        <p className="mt-2 text-[11px] leading-relaxed text-amber-200/80">{ticket.reviewReasons.join(" ")}</p>
      )}
      <div className="mt-3 flex items-center justify-between gap-2 text-[10px] text-gray-500">
        <span className="truncate font-mono" title={ticket.id}>{ticket.id}</span>
        <time className="shrink-0" dateTime={new Date(ticket.createdAt).toISOString()}>
          {new Date(ticket.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
        </time>
      </div>
      <p className="mt-2 flex items-center gap-1 text-[10px] text-gray-500"><Clock className="h-3 w-3" /> Awaiting review</p>
    </button>
  )
}
