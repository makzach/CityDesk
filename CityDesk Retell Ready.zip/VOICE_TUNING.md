# CityDesk voice: natural closing and Saint George Street

This update is for the original Retell website project. It changes the prompt supplied with the project. It has not been applied to your hosted Retell agent: no Retell account connection or private key is available in this workspace.

## Apply to the existing agent

1. In Retell, open the CityDesk single-prompt agent used by your website.
2. Replace its prompt with the full contents of `RETELL_AGENT_PROMPT.txt`. Replace the old prompt rather than appending another closing instruction that conflicts with it.
3. If an **End Call** tool is already configured, check its termination instructions. Use: **End only after the caller has finished and the agent has spoken its full closing. A report confirmation alone is not a request to hang up. Never end while awaiting an answer to a question. Respect an explicit caller request to end.** If there is no End Call tool, you can continue ending the conversation with the widget button.
4. Save the prompt and publish the updated agent version used by your website. Start a new conversation in the existing website widget. No website reinstall, new API key, or additional service is needed for this prompt edit.

## Expected conversation

**Agent:** A water leak on Saint George Street, across from Robarts Library in Toronto. Is that correct?

**Caller:** Yes.

**Agent:** Thanks for confirming. Before we finish, is there anything else you'd like to add about this issue?

The agent waits for your answer here.

**Caller:** No, that's everything.

**Agent:** All right, thank you for taking the time to report this. Take care, and goodbye.

If you add or correct a detail, it updates the summary and asks you to confirm again before closing. If you already said that is everything or asked to finish, it gives the warm closing without making you answer an unnecessary extra question.

## Pronunciation and mapping

All spoken location examples now spell out **Saint George Street**. The prompt explicitly expands the opening St. to Saint, including when the transcript uses the abbreviation. The extraction field can continue storing **St. George Street**; the existing map matcher already accepts both spellings. The location, pin, report extraction and reset behavior are unchanged.

## Quick rehearsal

Say the usual water-leak report, confirm it, and check that the agent says **Saint George Street** and waits after its final question. In a second rehearsal, add a correction at that question and check that the final read-back is confirmed again. Prompt text was checked for conflicting closing instructions; live voice behavior still needs this rehearsal.

Retell references: [Single-prompt behavior](https://docs.retellai.com/build/single-multi-prompt/prompt-overview) and [End Call tool conditions](https://docs.retellai.com/build/single-multi-prompt/end-call).
