# CityDeskOS — Retell voice intake

This version connects your existing Retell voice agent to the dashboard. A visitor talks through the **Talk to CityDesk** widget. After the conversation ends and Retell finishes analysis, the dashboard retrieves the extracted report and displays it. No phone number is required.

**Robarts water-leak update:** see `ROBARTS_SETUP.md` for the quick Mac update and the Retell settings. `RETELL_AGENT_PROMPT.txt` contains the replacement spoken script.

**Natural closing and pronunciation:** the updated `RETELL_AGENT_PROMPT.txt` now tells the agent to say **Saint George Street**, invite any final details, wait for the answer, and finish with a warm closing. Apply it in Retell using `VOICE_TUNING.md`; changing website files alone does not update the hosted voice agent.

**Fresh start on reopening:** each browser page load starts with no reports, no pins and the map zoomed out. Only calls ending after that page was opened are shown. Press Command + R to clear the screen between rehearsals. This resets the dashboard view; saved calls remain in Retell (or the optional database). See `RESET_SETUP.md` to apply this update to an existing installation.

## Fastest setup: three Retell settings

The default uses Retell's saved call history, so **no Supabase account and no webhook setup are required**. Reports remain available according to your Retell retention settings; this is not an independent archive.

1. Replace your existing project's source with the files in this ZIP, or commit them to the repository already connected to your Vercel project. Keep your existing project and domain. Do not upload `node_modules` or `.next`.
2. In Vercel → your project → Settings → Environment Variables, add:

   | Variable | Value |
   | --- | --- |
   | `NEXT_PUBLIC_RETELL_AGENT_ID` | The ID of your CityDesk voice agent |
   | `NEXT_PUBLIC_RETELL_PUBLIC_KEY` | A Retell **public** key enabled for this agent's browser voice calls |
   | `RETELL_API_KEY` | Your Retell private account API key, used only on the server to read completed analysis |

   Public key and private API key are different. Never paste the private API key into the public-key field or put `NEXT_PUBLIC_` on its name. Add keys in Vercel yourself; do not commit them. Configure the public key's allowed domains/agent permissions for your deployed site in Retell where available.
3. Keep BOTH optional Supabase variables unset. Redeploy after entering the three Retell values. Public variables are included at build time, so restarting an old deployment is insufficient.
4. In Retell, ensure the agent version used by the widget includes these exact post-call extraction names:

   | Field | Retell extraction type |
   | --- | --- |
   | `issue_category` | Text or selector: Water Leak / Pothole / Road Damage / Other |
   | `description` | Text |
   | `street_or_intersection` | Text: final corrected location only |
   | `city` | Text, default Toronto unless the caller specifies another city |
   | `location_details` | Text: side of road, nearby objects, etc. |
   | `caller_confirmed` | Boolean, not the text "true" |

   Ask the extraction to put just the street/intersection/landmark in `street_or_intersection`, and extra positioning in `location_details`. Do not include rejected earlier locations in the final location field. Keep post-call analysis available in Retell's call history. The widget uses the latest version when no version is specified.
5. Open your deployed HTTPS website. Click **Talk to CityDesk**, allow microphone access, report the issue and confirm the read-back. End the call. The feed checks for updates every two seconds, after each request completes. Retell's analysis adds an additional delay; the exact delay is not guaranteed.

There is no need to buy a separate AI API subscription. This DOES use your Retell account's public/private keys and Retell's normal voice usage. The private key never goes to the browser.

## Rehearse this call

Say **"There is a water leak on St. George Street, across from Robarts Library in Toronto."** Answer any follow-up, confirm the final summary and end the conversation. After Retell finishes analysis, the new report should show the water leak and a pin on St. George Street opposite Robarts. The map automatically zooms in. Refresh the browser before another rehearsal to clear the feed and reset the map. **City view** zooms out while keeping the current session's reports. This integration processes completed calls; it does not pin a location while you are still speaking.

The matcher accepts the street and landmark together or in separate `street_or_intersection` and `location_details` fields. Update the Retell category options to include Water Leak; an older selector returning Other is also handled when the description explicitly says water leak. Unknown locations and reports without confirmation appear as **Needs review**, without a guessed pin.

The map recognizes these reference points:

- St. George Street across from Robarts Library (St. / Saint / Saint Georges; across from / opposite).
- College Street & Spadina Avenue (either street order; `and`, `&`, `/`, or `at`).
- College Street & Bathurst Street (same variants).
- Bata Shoe Museum / 327 Bloor Street West.

The Robarts point is a preset roadway reference opposite the library, between the Harbord and Sussex intersections checked with Esri World Geocoding on 2026-09-19. Other points locate an intersection or landmark. These are approximate reported areas, not surveyed defect positions. This limited lookup requires no geocoding API key. All other reports still appear, but without a pin. Extend `lib/demo-locations.ts` with checked locations or implement a geocoder for wider coverage.

## What changed

- Embedded your Retell agent using its official voice-only website widget.
- Added `GET /api/reports`, which reads the latest 100 calls for the configured agent, filters completed browser calls with extraction data, and returns only report fields. Older calls beyond that window are not shown.
- The feed starts empty on every page load, shows only calls ending during that session, automatically refreshes, retains current cards on connection errors, and selects new reports. Cards show actual description, final address, location details, and caller confirmation. Polling and the small feed refresh button keep the same session; a browser reload starts a new one.
- Replaced the fake speech-recognition intake, random categories, and fixed-location clarification. Removed simulated dispatch controls that claimed a crew had been sent; reports are now awaiting operator review.
- Added optional signed webhook + Supabase storage, if you later want your own archive.
- Enabled TypeScript build checks instead of ignoring build errors.

This is a shared hackathon demo dashboard, not an authenticated municipal operator system. Everyone who can open it can view the extracted descriptions/locations for this agent. Use fictional reports and a dedicated demo agent. Raw transcripts, recordings, caller-number metadata, and access tokens are not returned to the website; free-text descriptions may still contain anything a caller says. No real city tickets, crews or emergency transfers are created.

## If something does not work

| Symptom | Check |
| --- | --- |
| "Voice chat is not connected yet" | Both `NEXT_PUBLIC_` variables are set, then redeploy. |
| Widget loads but cannot start | Public key/agent permissions, domain restrictions, microphone permission, Retell balance, and any required verification or reCAPTCHA settings. |
| "Report connection unavailable" | Server `RETELL_API_KEY`, agent ID, account permissions and service availability. Keep Supabase variables blank in default mode. |
| Voice works but no ticket | End the actual browser voice conversation. Wait for analysis. In Retell call history, inspect `call_analysis.custom_analysis_data` and the exact six field names. A text simulation does not create a completed web call. |
| Report shows but no pin | Confirm the summary and use one supported location. Extra prose belongs in `location_details`. Unknown/ambiguous locations deliberately need review. |
| Older test reports appear | Make sure the fresh-session update is installed, then reload the page. The dashboard filters out calls that ended before you opened it. Retell still keeps the underlying call history. |
| My latest report disappeared after a browser refresh | Expected: a browser reload starts a new empty session. Make the next call after opening the page, then leave the page open while analysis completes. |

## Optional: archive reports in Supabase using a webhook

Skip this entire section for the fastest setup above. When **both** Supabase variables are set, the dashboard switches to the database; it no longer reads Retell history. Existing Retell calls are not backfilled automatically.

1. Create/use a Supabase project and run `supabase/setup.sql` in its SQL Editor.
2. Set server-only `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` in Vercel. Use the legacy **service_role** key, not the public anon key. Retain the three Retell variables. Redeploy.
3. In Retell, set this agent's webhook URL to `https://YOUR-DEPLOYED-DOMAIN/api/retell-webhook`, subscribe to `call_analyzed`, and make a new call. For the existing domain, that URL would be `https://strata-seven-dusky.vercel.app/api/retell-webhook` once this code is deployed there.
4. Retell must be able to reach the endpoint; a Vercel preview login screen will block delivery. Use a reachable deployment. Requests are still authenticated using Retell's signature, not an unprotected write route.

The endpoint verifies the raw request signature and timestamp, checks the agent, extracts only the report fields, and inserts once per call ID. Failed writes return 503 so Retell can retry; the database primary key makes retries safe. In this mode saved reports survive deletion of the call from Retell.

## Local development and checks

Use a recent Node.js LTS (Node 22 or newer) and pnpm. Copy `.env.example` to `.env.local`, fill the three Retell values, then run:

```sh
pnpm install
pnpm dev
```

Open `http://localhost:3000`. If Retell public-key domain restrictions are configured, allow your development origin for testing.

```sh
pnpm test
pnpm typecheck
pnpm build
```

The automated tests use fixtures and mocked upstream responses. They check Robarts address variants, split street/landmark extraction, water-leak labels, corrected location handling, missing confirmation, data filtering, signature validation, retry behavior, and failed storage. A real voice call still needs your credentials and deployment.

Validation on this delivered version: the production build (including TypeScript) and automated integration tests passed. Browser visual verification was blocked by a failed browser download. No live Retell call or Supabase connection was tested because credentials were not supplied. This ZIP has not been deployed to your Vercel site.

## Reference documentation

- [Retell voice widget](https://docs.retellai.com/deploy/chat-widget)
- [Retell list calls: current v3 endpoint](https://docs.retellai.com/api-references/list-calls)
- [Retell webhook events](https://docs.retellai.com/features/webhook-overview)
- [Webhook signature format](https://docs.retellai.com/features/secure-webhook)
- [Supabase REST API](https://supabase.com/docs/guides/api)
