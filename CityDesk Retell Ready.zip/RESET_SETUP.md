# Reset the dashboard whenever you reopen it

This update starts each new browser page load with an empty report list, zero pins and the map zoomed out. Reports from calls that end after you open the page appear normally. A call that ended earlier stays hidden even if Retell finishes analyzing it later.

## Install on your Mac

1. Save `citydesk-reset-update.zip` in Downloads. Leave it zipped.
2. In the Terminal running the website, press Control + C.
3. Run:

```sh
cd ~/Downloads/citydesk-retell-ready
unzip -o ~/Downloads/citydesk-reset-update.zip
npm run dev
```

4. Open the exact Local URL shown in Terminal, then refresh that page. You should see **No reports this session**, zero report pins and the wider Toronto map.

Your existing keys and Retell agent settings stay in place. No package installation is needed.

## Use it during your pitch

Press **Command + R** before starting to clear the dashboard and reset the map. Start your voice call, report the water leak across from Robarts Library, confirm the read-back and end the conversation. Leave the page open while Retell finishes processing and the report arrives.

Refreshing or reopening the website starts another empty session. The small refresh icon beside the report count only checks for new reports; it keeps the current session. **City view** zooms out without clearing reports. Restarting the development server alone does not reset a browser tab that remains open: reload the tab too.

This clears the website's visible session history. Saved calls remain in Retell and any optional report database; the update does not delete them. The report API still provides saved report data, and the dashboard filters it for the current session. Session timing uses your computer's clock and the call's end time, so keep the computer's date and time set correctly.
