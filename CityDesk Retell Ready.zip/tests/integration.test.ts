import assert from "node:assert/strict"
import { createHmac } from "node:crypto"
import test from "node:test"
import { reportFromCall } from "../lib/retell-report"
import { resolveDemoLocation } from "../lib/demo-locations"
import { verifyRetellSignature } from "../lib/retell-signature"
import { GET } from "../app/api/reports/route"
import { POST } from "../app/api/retell-webhook/route"

function makeCall(overrides: Record<string, unknown> = {}) {
  return {
    call_id: "call_citydesk_test",
    call_type: "web_call",
    agent_id: "agent_citydesk_test",
    call_status: "ended",
    end_timestamp: 1789810000000,
    transcript: "Caller: College and Bathurst. Actually, I mean College and Spadina. Yes, confirmed.",
    from_number: "+15555550123",
    access_token: "must-never-reach-browser",
    call_analysis: { custom_analysis_data: {
      issue_category: "Pothole",
      description: "Large pothole beside the eastbound curb.",
      street_or_intersection: "College Street and Spadina Avenue",
      city: "Toronto",
      location_details: "Eastbound lane",
      caller_confirmed: true,
      ...overrides,
    } },
  }
}

function signedRequest(body: unknown, key: string, timestamp = Date.now()) {
  const raw = JSON.stringify(body)
  const digest = createHmac("sha256", key).update(raw + timestamp).digest("hex")
  return new Request("https://citydesk.example/api/retell-webhook", {
    method: "POST", body: raw,
    headers: { "Content-Type": "application/json", "x-retell-signature": `v=${timestamp},d=${digest}` },
  })
}

test("CityDesk report pipeline", async (t) => {
  const originalFetch = globalThis.fetch
  const names = ["RETELL_API_KEY", "NEXT_PUBLIC_RETELL_AGENT_ID", "SUPABASE_URL", "SUPABASE_SERVICE_ROLE_KEY"]
  const originalEnv = Object.fromEntries(names.map((name) => [name, process.env[name]]))
  t.after(() => {
    globalThis.fetch = originalFetch
    for (const name of names) {
      if (originalEnv[name] === undefined) delete process.env[name]
      else process.env[name] = originalEnv[name]
    }
  })
  process.env.RETELL_API_KEY = "test-private-key"
  process.env.NEXT_PUBLIC_RETELL_AGENT_ID = "agent_citydesk_test"
  delete process.env.SUPABASE_URL
  delete process.env.SUPABASE_SERVICE_ROLE_KEY

  await t.test("uses corrected extraction rather than an earlier location in the transcript", () => {
    const report = reportFromCall(makeCall())!
    assert.equal(report.address, "College Street and Spadina Avenue")
    assert.equal(report.lng, -79.400211004261)
    assert.equal(report.status, "ready")
    assert.equal(report.description, "Large pothole beside the eastbound curb.")
    assert.ok(!("transcript" in report) && !("access_token" in report) && !("from_number" in report))
  })
  await t.test("handles common intersection spellings without matching vague or conflicting locations", () => {
    for (const address of ["College St. & Spadina Ave., Toronto", "Spadina/College", "College at Spadina"]) {
      assert.equal(resolveDemoLocation(address, "Toronto")?.name, "College Street & Spadina Avenue")
    }
    for (const address of ["College Street", "College and Bathurst or College and Spadina", "100 College Street"]) {
      assert.equal(resolveDemoLocation(address, "Toronto"), null)
    }
    assert.equal(resolveDemoLocation("College and Spadina", "Vancouver"), null)
  })
  await t.test("maps a confirmed Robarts water leak whether Retell splits the street and landmark or combines them", () => {
    const variants = [
      ["St. George Street, across from Robarts Library", ""],
      ["Saint Georges Street directly across the street from Robarts Library, Toronto", ""],
      ["On St George St. opposite Robarts Library", ""],
      ["St. George Street", "Across from Robarts Library"],
      ["Saint George's Street", "East side; directly across from Robarts Research Library."],
    ]
    for (const [address, details] of variants) {
      const report = reportFromCall(makeCall({
        issue_category: "Water Leak",
        description: "Water is leaking onto the road from the curb.",
        street_or_intersection: address,
        location_details: details,
      }))!
      assert.equal(report.status, "ready", address)
      assert.equal(report.issueType, "Water Leak")
      assert.equal(report.lng, -79.398653, address)
      assert.equal(report.lat, 43.664705, address)
      assert.equal(report.locationDetails, details)
    }
  })
  await t.test("does not assume the Robarts location for other streets, uncertain details or unconfirmed calls", () => {
    for (const [address, details, city] of [
      ["St. George Street", "", "Toronto"],
      ["Bathurst Street", "Across from Robarts Library", "Toronto"],
      ["St. George Street", "Not across from Robarts Library", "Toronto"],
      ["St. George Street", "Across from Robarts Library; or maybe Bloor Street", "Toronto"],
      ["St. George Street", "Across from Robarts Library", "Vancouver"],
      ["St. George Street or College Street", "Across from Robarts Library", "Toronto"],
    ]) assert.equal(resolveDemoLocation(address, city, details), null, `${address}: ${details}`)
    const report = reportFromCall(makeCall({
      issue_category: "Water Leak", street_or_intersection: "St. George Street",
      location_details: "Across from Robarts Library", caller_confirmed: false,
    }))!
    assert.equal(report.lng, null)
    assert.equal(report.status, "needs_review")
  })
  await t.test("labels explicit water leaks when an older Retell category selector returns Other", () => {
    const report = reportFromCall(makeCall({
      issue_category: "Other", description: "Water leak on St George Street, across from Robarts Library.",
      street_or_intersection: "St. George Street", location_details: "Across from Robarts Library",
    }))!
    assert.equal(report.issueType, "Water Leak")
    assert.equal(report.status, "ready")
    for (const description of ["Litter beside a tree.", "There is no water leak; just litter."]) {
      assert.equal(reportFromCall(makeCall({ issue_category: "Other", description }))?.issueType, "Other")
    }
  })
  await t.test("unconfirmed, missing or malformed confirmations never produce a pin", () => {
    for (const value of [false, undefined, "true", "false", 1]) {
      const report = reportFromCall(makeCall({ caller_confirmed: value }))!
      assert.equal(report.status, "needs_review")
      assert.equal(report.lng, null)
      assert.equal(report.lat, null)
    }
    assert.equal(reportFromCall(makeCall({ street_or_intersection: "Somewhere downtown" }))?.lng, null)
  })
  await t.test("ignores empty, unfinished and unanalyzed calls", () => {
    assert.equal(reportFromCall({ ...makeCall(), call_status: "ongoing" }), null)
    assert.equal(reportFromCall({ ...makeCall(), call_analysis: {} }), null)
    assert.equal(reportFromCall(makeCall({ description: "", street_or_intersection: "" })), null)
  })
  await t.test("default history feed filters other agents, deduplicates and strips private call metadata", async () => {
    globalThis.fetch = async (input, init) => {
      assert.equal(String(input), "https://api.retellai.com/v3/list-calls")
      assert.deepEqual(JSON.parse(String(init?.body)).filter_criteria, { agent: [{ agent_id: "agent_citydesk_test" }] })
      return Response.json({ has_more: false, items: [
        makeCall(), makeCall(), { ...makeCall(), agent_id: "another_agent" },
        { ...makeCall(), call_id: "call_unfinished", call_status: "ongoing" },
      ] })
    }
    const response = await GET()
    assert.equal(response.status, 200)
    const data = await response.json()
    assert.equal(data.tickets.length, 1)
    assert.equal(data.tickets[0].address, "College Street and Spadina Avenue")
    const serialized = JSON.stringify(data)
    assert.ok(!serialized.includes("must-never-reach-browser"))
    assert.ok(!serialized.includes("+15555550123"))
    assert.ok(!serialized.includes("test-private-key"))
  })
  await t.test("upstream failure produces an error, not an empty successful feed", async () => {
    process.env.RETELL_API_KEY = "another-test-key" // separate history-cache scope
    globalThis.fetch = async () => new Response(null, { status: 429 })
    assert.equal((await GET()).status, 503)
    process.env.RETELL_API_KEY = "test-private-key"
  })
  await t.test("signature verification rejects tampering, wrong keys and expired deliveries", () => {
    const now = Date.now()
    const raw = '{"event":"call_analyzed"}'
    const digest = createHmac("sha256", "secret").update(raw + now).digest("hex")
    const signature = `v=${now},d=${digest}`
    assert.equal(verifyRetellSignature(raw, signature, "secret", now), true)
    assert.equal(verifyRetellSignature(raw + " ", signature, "secret", now), false)
    assert.equal(verifyRetellSignature(raw, signature, "wrong", now), false)
    assert.equal(verifyRetellSignature(raw, signature, "secret", now + 300001), false)
  })

  process.env.SUPABASE_URL = "https://database.example"
  process.env.SUPABASE_SERVICE_ROLE_KEY = "test-service-role"
  const database = new Map<string, unknown>()
  let writes = 0
  globalThis.fetch = async (input, init) => {
    if (init?.method === "POST") {
      assert.ok(String(input).includes("on_conflict=call_id"))
      assert.equal(new Headers(init.headers).get("Prefer"), "resolution=ignore-duplicates,return=minimal")
      const row = JSON.parse(String(init.body))
      if (!database.has(row.call_id)) database.set(row.call_id, row)
      writes++
      return new Response(null, { status: 201 })
    }
    return Response.json([...database.values()])
  }
  await t.test("webhook rejects unsigned requests before writing anything", async () => {
    const response = await POST(new Request("https://citydesk.example/api/retell-webhook", { method: "POST", body: "{}" }))
    assert.equal(response.status, 401)
    assert.equal(writes, 0)
  })
  await t.test("valid analyzed webhook stores a report; retry uses conflict-safe insertion", async () => {
    for (let i = 0; i < 2; i++) {
      assert.equal((await POST(signedRequest({ event: "call_analyzed", call: makeCall() }, "test-private-key"))).status, 204)
    }
    assert.equal(writes, 2)
    assert.equal(database.size, 1)
    const data = await (await GET()).json()
    assert.equal(data.tickets.length, 1)
    assert.equal(data.tickets[0].callerConfirmed, true)
  })
  await t.test("other agents and call_ended events do not create reports", async () => {
    const before = writes
    for (const body of [
      { event: "call_ended", call: makeCall() },
      { event: "call_analyzed", call: { ...makeCall(), agent_id: "unrelated" } },
    ]) assert.equal((await POST(signedRequest(body, "test-private-key"))).status, 204)
    assert.equal(writes, before)
  })
  await t.test("database failure asks Retell to retry instead of acknowledging lost data", async () => {
    globalThis.fetch = async () => new Response(null, { status: 500 })
    assert.equal((await POST(signedRequest({ event: "call_analyzed", call: makeCall() }, "test-private-key"))).status, 503)
  })
})
