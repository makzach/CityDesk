-- Run once in your Supabase project's SQL Editor.
create table if not exists public.citydesk_reports (
  call_id text primary key,
  report jsonb not null check (jsonb_typeof(report) = 'object'),
  created_at timestamptz not null default now()
);
create index if not exists citydesk_reports_created_at_idx
  on public.citydesk_reports (created_at desc);

-- Only the server's service-role key can access this table directly.
alter table public.citydesk_reports enable row level security;
revoke all on table public.citydesk_reports from anon, authenticated;
grant select, insert on table public.citydesk_reports to service_role;
