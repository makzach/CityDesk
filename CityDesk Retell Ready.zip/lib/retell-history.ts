import { asRecord, reportFromCall } from "./retell-report"
import type { Ticket } from "./dispatch"

// Retell remains the persistent source of truth in the default demo mode.
// This short cache only limits repeated upstream reads; it is not storage.
let cached: { scope: string; expires: number; tickets: Ticket[] } | null = null
let pending: { scope: string; result: Promise<Ticket[]> } | null = null

export function historyConfigured(): boolean {
  return Boolean(process.env.RETELL_API_KEY && process.env.NEXT_PUBLIC_RETELL_AGENT_ID)
}

export async function listRetellReports(): Promise<Ticket[]> {
  const apiKey = process.env.RETELL_API_KEY
  const agentId = process.env.NEXT_PUBLIC_RETELL_AGENT_ID
  if (!apiKey || !agentId) throw new Error("Retell is not configured")
  const scope = `${agentId}:${apiKey}`
  if (cached?.scope === scope && cached.expires > Date.now()) return cached.tickets
  if (pending?.scope === scope) return pending.result

  const result = (async () => {
    // Current API is v3: its response is { items, has_more, pagination_key }.
    // Never return raw calls (which may contain tokens or caller information).
    const response = await fetch("https://api.retellai.com/v3/list-calls", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        filter_criteria: { agent: [{ agent_id: agentId }] },
        sort_order: "descending",
        limit: 100,
      }),
      cache: "no-store",
      signal: AbortSignal.timeout(7000),
    })
    if (!response.ok) throw new Error(`Retell history returned ${response.status}`)
    const data = asRecord(await response.json())
    if (!data || !Array.isArray(data.items)) throw new Error("Invalid Retell history response")
    const unique = new Map<string, Ticket>()
    for (const item of data.items) {
      const call = asRecord(item)
      if (!call || call.agent_id !== agentId || call.call_type !== "web_call") continue
      const report = reportFromCall(call)
      if (report) unique.set(report.id, report)
    }
    const tickets = [...unique.values()].sort((a, b) => b.createdAt - a.createdAt)
    cached = { scope, expires: Date.now() + 2000, tickets }
    return tickets
  })()
  const flight = { scope, result }
  pending = flight
  try { return await result }
  finally { if (pending === flight) pending = null }
}
