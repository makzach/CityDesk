import type { Ticket } from "./dispatch"
import { resolveDemoLocation } from "./demo-locations"

export function asRecord(value: unknown): Record<string, unknown> | null {
  return typeof value === "object" && value !== null && !Array.isArray(value)
    ? value as Record<string, unknown> : null
}

function text(value: unknown, max: number): string {
  return typeof value === "string" ? value.trim().slice(0, max) : ""
}

export function reportFromCall(value: unknown): Ticket | null {
  const call = asRecord(value)
  if (!call || typeof call.call_id !== "string" || !/^[\w-]{1,128}$/.test(call.call_id)) return null
  if (call.call_status !== "ended") return null
  const analysis = asRecord(call.call_analysis)
  const data = asRecord(analysis?.custom_analysis_data)
  if (!data) return null

  const description = text(data.description, 2000)
  const address = text(data.street_or_intersection, 300)
  if (!description && !address) return null
  let category = text(data.issue_category, 100)
  // Older agents may still have only Pothole / Road Damage / Other options.
  // Use the caller's extracted description to label an explicit water leak.
  if ((!category || /^other$/i.test(category))
    && /\b(?:water leak|leaking water|water main (?:break|leak))\b/i.test(description)
    && !/\b(?:no|not|without|isn't|is not)\b/i.test(description)) category = "Water Leak"
  if (/^water[ -]leak$/i.test(category)) category = "Water Leak"
  const city = text(data.city, 100) || "Toronto"
  const locationDetails = text(data.location_details, 500)
  const callerConfirmed = typeof data.caller_confirmed === "boolean" ? data.caller_confirmed : null
  const location = callerConfirmed === true ? resolveDemoLocation(address, city, locationDetails) : null
  const reviewReasons: string[] = []
  if (callerConfirmed !== true) reviewReasons.push("The caller did not confirm the report.")
  if (!address) reviewReasons.push("No street or intersection was provided.")
  else if (!location && callerConfirmed === true) reviewReasons.push("Location needs manual verification before mapping.")
  if (!description) reviewReasons.push("The issue description is missing.")
  if (!category) reviewReasons.push("The issue category is missing.")
  const endedAt = call.end_timestamp

  return {
    id: call.call_id,
    issueType: category || "Other",
    description,
    address,
    city,
    locationDetails,
    lng: location?.lng ?? null,
    lat: location?.lat ?? null,
    callerConfirmed,
    status: reviewReasons.length ? "needs_review" : "ready",
    reviewReasons,
    createdAt: typeof endedAt === "number" && Number.isFinite(endedAt) && endedAt > 0
      && endedAt <= Date.now() + 300_000 ? endedAt : Date.now(),
  }
}
