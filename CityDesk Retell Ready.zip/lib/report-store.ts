import type { Ticket } from "./dispatch"

// Server routes only. Never import this module from a client component.
export function storageConfigured(): boolean {
  return Boolean(process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY)
}

function config() {
  const url = process.env.SUPABASE_URL?.replace(/\/$/, "")
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY
  if (!url || !key) throw new Error("Report storage is not configured")
  return { url, key }
}

export async function saveReport(ticket: Ticket): Promise<void> {
  const { url, key } = config()
  const response = await fetch(`${url}/rest/v1/citydesk_reports?on_conflict=call_id`, {
    method: "POST",
    headers: {
      apikey: key,
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/json",
      Prefer: "resolution=ignore-duplicates,return=minimal",
    },
    body: JSON.stringify({ call_id: ticket.id, report: ticket, created_at: new Date(ticket.createdAt).toISOString() }),
    cache: "no-store",
    signal: AbortSignal.timeout(7000),
  })
  if (!response.ok) throw new Error(`Report storage returned ${response.status}`)
}

export async function listReports(): Promise<Ticket[]> {
  const { url, key } = config()
  const response = await fetch(`${url}/rest/v1/citydesk_reports?select=report&order=created_at.desc,call_id.desc&limit=100`, {
    headers: { apikey: key, Authorization: `Bearer ${key}` },
    cache: "no-store",
    signal: AbortSignal.timeout(7000),
  })
  if (!response.ok) throw new Error(`Report storage returned ${response.status}`)
  const rows = await response.json() as { report: Ticket }[]
  return rows.map((row) => row.report)
}
