import { createHmac, timingSafeEqual } from "node:crypto"

// https://docs.retellai.com/features/secure-webhook
export function verifyRetellSignature(rawBody: string, signature: string | null, key: string, now = Date.now()): boolean {
  if (!signature || !key) return false
  const match = /^v=(\d+),d=([a-f\d]{64})$/i.exec(signature)
  if (!match) return false
  const timestamp = Number(match[1])
  if (!Number.isSafeInteger(timestamp) || Math.abs(now - timestamp) > 300_000) return false
  const expected = createHmac("sha256", key).update(rawBody + match[1]).digest()
  const received = Buffer.from(match[2], "hex")
  return received.length === expected.length && timingSafeEqual(expected, received)
}
