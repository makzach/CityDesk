export type Ticket = {
  id: string
  issueType: string
  description: string
  address: string
  city: string
  locationDetails: string
  lng: number | null
  lat: number | null
  callerConfirmed: boolean | null
  status: "ready" | "needs_review"
  reviewReasons: string[]
  createdAt: number
}

export const TORONTO_CENTER = { longitude: -79.398, latitude: 43.661, zoom: 13.2 }

export function hasMapLocation(ticket: Ticket): ticket is Ticket & { lng: number; lat: number } {
  return ticket.callerConfirmed === true && Number.isFinite(ticket.lng) && Number.isFinite(ticket.lat)
}
