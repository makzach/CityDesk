// Supported reference points, not a general-purpose geocoder.
// A marker identifies a reported area, not a surveyed defect position.
// Robarts reference: St. George roadway opposite the library, between
// Harbord and Sussex. Those intersections were checked with Esri, 2026-09-19.
// Library address: https://library.utoronto.ca/library/robarts
export const ROBARTS_LOCATION = {
  name: "St. George Street · Across from Robarts Library",
  aliases: [
    "st george opposite robarts library",
    "st george opposite robarts",
    "st george robarts library",
    "opposite robarts library on st george",
  ],
  lng: -79.398653,
  lat: 43.664705,
} as const

export const DEMO_LOCATIONS = [
  ROBARTS_LOCATION,
  {
    name: "College Street & Spadina Avenue",
    aliases: ["college and spadina", "spadina and college"],
    lng: -79.400211004261,
    lat: 43.657962020327,
  },
  {
    name: "College Street & Bathurst Street",
    aliases: ["college and bathurst", "bathurst and college"],
    lng: -79.40770702409,
    lat: 43.656475070704,
  },
  {
    name: "Bata Shoe Museum",
    aliases: ["bata shoe museum", "327 bloor west"],
    lng: -79.4001932,
    lat: 43.6672976,
  },
] as const

function normalize(value: string): string {
  return value.toLowerCase()
    .replace(/[’']/g, "")
    // Preserve Saint George before removing abbreviations for "Street".
    .replace(/\b(?:saint|st\.?)\s+georges?\b/g, "saint george")
    .replace(/\b(?:directly\s+)?(?:across(?:\s+the\s+(?:street|road))?\s+from|opposite(?:\s+to)?)\b/g, "opposite")
    .replace(/\brobarts research library\b/g, "robarts library")
    .replace(/\b(street|st|avenue|ave|road|rd)\b\.?/g, " ")
    .replace(/\b(w)\b\.?/g, "west")
    .replace(/\s*(?:&|\/|\bat\b)\s*/g, " and ")
    .replace(/[.,;():]/g, " ")
    .replace(/\s+/g, " ").trim()
}

export function resolveDemoLocation(address: string, city: string, locationDetails = "") {
  if (!/^toronto(?:\s*,\s*(?:ontario|on)(?:\s*,\s*canada)?)?$/i.test(city.trim())) return null
  const normalized = normalize(address)
    .replace(/(?:\s+and)?\s+toronto(?:\s+(?:ontario|on))?(?:\s+canada)?$/, "")
    .replace(/^(?:on |along |at |and |intersection of |corner of )/, "")
    .trim()
  // Exact matching prevents vague streets or multiple candidate locations
  // from silently snapping to one of our supported points.
  const exact = DEMO_LOCATIONS.find((location) =>
    location.aliases.some((alias) => normalize(alias) === normalized)
  )
  if (exact) return exact

  // Retell often separates the street from the nearby landmark. Match the
  // final extracted details, never an earlier location in the transcript.
  if (normalized !== "saint george") return null
  if (/\b(?:not|instead|or|maybe|possibly|unsure)\b/i.test(locationDetails)) return null
  const detailParts = locationDetails.split(/[;,]/).map(normalize)
  const landmark = /^(?:opposite robarts(?: library)?|robarts library)$/
  return detailParts.some((part) => landmark.test(part)) ? ROBARTS_LOCATION : null
}
